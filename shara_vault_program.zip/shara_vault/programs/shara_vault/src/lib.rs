use anchor_lang::prelude::*;

declare_id!("9EnbaVoFqvh4vjz5GWzoo5ZSQp2soxp3n4wNjmKSqepA");

#[program]
pub mod shara_vault {
    use super::*;

    pub fn initialize_vault(ctx: Context<InitializeVault>, bump: u8) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.authority = *ctx.accounts.authority.key;
        vault.balance = 0;
        vault.bump = bump;
        Ok(())
    }

    pub fn deposit(ctx: Context<Deposit>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;
        vault.balance += amount;

        let ix = anchor_lang::solana_program::system_instruction::transfer(
            &ctx.accounts.authority.key(),
            &ctx.accounts.vault.key(),
            amount,
        );
        anchor_lang::solana_program::program::invoke(
            &ix,
            &[
                ctx.accounts.authority.to_account_info(),
                ctx.accounts.vault.to_account_info(),
            ],
        )?;

        Ok(())
    }

    pub fn withdraw(ctx: Context<Withdraw>, amount: u64) -> Result<()> {
        let vault = &mut ctx.accounts.vault;

        require!(
            vault.authority == ctx.accounts.authority.key(),
            VaultError::Unauthorized
        );
        require!(vault.balance >= amount, VaultError::InsufficientFunds);

        **ctx.accounts.vault.to_account_info().try_borrow_mut_lamports()? -= amount;
        **ctx.accounts.destination.to_account_info().try_borrow_mut_lamports()? += amount;

        vault.balance -= amount;
        Ok(())
    }

    pub fn close_vault(ctx: Context<CloseVault>) -> Result<()> {
        require!(
            ctx.accounts.vault.authority == ctx.accounts.authority.key(),
            VaultError::Unauthorized
        );

        let remaining = ctx.accounts.vault.balance;
        **ctx.accounts.vault.to_account_info().try_borrow_mut_lamports()? -= remaining;
        **ctx.accounts.destination.to_account_info().try_borrow_mut_lamports()? += remaining;

        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitializeVault<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,

    #[account(
        init,
        payer = authority,
        space = 8 + 32 + 8 + 1,
        seeds = [b"vault", authority.key().as_ref()],
        bump
    )]
    pub vault: Account<'info, Vault>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Deposit<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,

    #[account(mut)]
    pub vault: Account<'info, Vault>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Withdraw<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,

    #[account(mut)]
    pub vault: Account<'info, Vault>,

    #[account(mut)]
    pub destination: AccountInfo<'info>,

    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct CloseVault<'info> {
    #[account(mut, signer)]
    pub authority: AccountInfo<'info>,

    #[account(mut, close = destination)]
    pub vault: Account<'info, Vault>,

    #[account(mut)]
    pub destination: AccountInfo<'info>,
}

#[account]
pub struct Vault {
    pub authority: Pubkey,
    pub balance: u64,
    pub bump: u8,
}

#[error_code]
pub enum VaultError {
    #[msg("You are not authorized to perform this action.")]
    Unauthorized,

    #[msg("Not enough SOL in the vault.")]
    InsufficientFunds,
}